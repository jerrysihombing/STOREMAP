    
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title> Yogya Space Intelligence </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="yogya, toserba yogya, yogya group, akur pratama" />
    <meta name="description" content="Welcome to Yogya Space Intelligence." />

    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">

	<!-- Le styles -->
    <link rel="stylesheet" type="text/css" href="../css/metro-bootstrap.css">
    <!-- documentation styles -->
    <link rel="stylesheet" type="text/css" href="../css/docs.css">
	  
	<!-- Using Font Awesome in tiles -->	  
	<link href="../css/font-awesome.css" rel="stylesheet">

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <!--<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>-->
	<script src="../script/html5.js"></script>
    <![endif]-->