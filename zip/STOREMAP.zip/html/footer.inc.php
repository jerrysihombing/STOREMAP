    <hr>
    
    <!-- Site footer -->
    <div class="footer">    
        <p style="color: #2777ad;">Copyright © 2015 Akur Pratama, PT.</p>		
    </div>