<?php 

require_once ("inc/main.inc.php");
require_once ("php/controller/FrontController.php");

$FC = new FrontController();
$FC->execute();

?> 