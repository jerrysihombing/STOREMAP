<?php

# yymm
$SRC = "1504";
# yyyymmdd
$FORM = "20150428";
# dd/mm/yy
$dayToProcess = "28/04/15";

$FORGE = "/Users/user/Data/TEMP";

# -- store live --
$STORE_LIVE[] = "183";

# -- MKG SERVER --
$FTP_SERVER["IP"] = "172.16.9.57";
$FTP_SERVER["USER"] = "royen";
$FTP_SERVER["PASSWD"] = "royen";
$FTP_SERVER["DIR"] = "/data/marketing/";
$FTP_SERVER["FILE_PREFIX"] = "MkgTrn";

?>