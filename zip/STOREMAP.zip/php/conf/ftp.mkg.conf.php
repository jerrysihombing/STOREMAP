<?php

$FORGE = "/Users/user/Data/TEMP";

# -- store live --
$STORE_LIVE[] = "183";

# -- MKG SERVER --
$FTP_SERVER["IP"] = "172.16.9.57";
$FTP_SERVER["USER"] = "royen";
$FTP_SERVER["PASSWD"] = "royen";
$FTP_SERVER["DIR"] = "/data/marketing/";
$FTP_SERVER["FILE_PREFIX"] = "MkgTrn";

?>